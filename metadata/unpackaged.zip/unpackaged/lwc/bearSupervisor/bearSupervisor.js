import { LightningElement, wire, api } from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
//import the Bear__c.Supervisor__c field via a schema import instead of using a hard-coded string
import SUPERVISOR_FIELD from '@salesforce/schema/Bear__c.Supervisor__c';
const bearFields = [SUPERVISOR_FIELD];

export default class BearSupervisor extends LightningElement {
    @api recordId; // Bear Id
    //retrieve the bear record using @wire decorator and the getRecord adapter.
    @wire(getRecord, {recordId: '$recordId', fields:bearFields})
    bear;
    
    //helper function to retrieve field values.
    //The expression uses the getFieldValue function to retrieve the value of the supervisor field.
    get supervisorId(){
        return getFieldValue(this.bear.data, SUPERVISOR_FIELD);
    }
}