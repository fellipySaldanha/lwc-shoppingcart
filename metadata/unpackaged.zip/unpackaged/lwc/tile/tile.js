import { LightningElement, api } from 'lwc';

export default class Tile extends LightningElement {
    @api product;

    tileClick(){
        //instanica o evento customizado, passando o nome do evento e sua execução
        const event = new CustomEvent('tileclick', {
            detail : this.product.fields.Id.value
        });
        //dispara o evento
        this.dispatchEvent(event);
    }
}