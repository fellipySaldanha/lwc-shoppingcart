import { LightningElement, track } from 'lwc';
//app use, gives us access to a static resource associated with our app.
import ursusResources from '@salesforce/resourceUrl/ursus_park';
//Apex method
import getAllBears from '@salesforce/apex/BearController.getAllBears'

export default class BearList extends LightningElement {
    @track bears;
    @track error;
    //static resource in app
    appResources = {
		bearSilhouette: ursusResources +'/img/standing-bear-silhouette.png',
    };
    //execute code after the component is loaded
    connectedCallback() {
		this.loadBears();
    }
    //calls the getAllBears adapter. The adapter calls our Apex code and returns a JS promise
    //Retrieving data using this approach is called imperative Apex.
    loadBears(){
        getAllBears()
        .then(result => {
            this.bears = result;
        })
        .catch(error => {
            this.error = error;
        });
    }
}