// lets us retrieve the current page reference and navigation
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
//helper function that lets us fire events across the page.
import { fireEvent } from 'c/pubsub';
import { LightningElement, wire, track } from 'lwc';
//import css from other component
import { loadStyle } from 'lightning/platformResourceLoader';
//app use
import ursusResources from '@salesforce/resourceUrl/ursus_park';
// Apex method 
import searchBears from '@salesforce/apex/BearController.searchBears';
export default class BearList extends NavigationMixin(LightningElement) {
    //searchTerm pass it as a parameter of our wired Apex call to searchBears.
    @track searchTerm = '';

    @track bears;
    //We retrieve the current page reference and store it in a pageRef property.
    @wire(CurrentPageReference) pageRef;

    //We use a wired function to capture incoming bear list data and fire a custom bearListUpdate event with the list of bear records.
    //We pass searchTerm as a dynamic parameter to our wired searchBears adapter so that each time searchTerm changes,
    // loadBears is re-executed and we fire a new event with the new search results.
    @wire(searchBears, {searchTerm: '$searchTerm'})
    loadBears(result) {
        window.console.log('result ' + result);
        this.bears = result;
        if (result.data) {
            window.console.log('res data ' + result.data);
            //fire this event across the whole Lightning page identified by pageRef.
            fireEvent(this.pageRef, 'bearListUpdate', result.data);
        }
    }
    
    //This imports a custom stylesheet defined in the Ursus Park static resource when the component loads.
	connectedCallback(){
        loadStyle(this, ursusResources + '/style.css');
    }
    
    //used to react to changes in the value of the search input field
    handleSearchTermChange(event){
        window.clearTimeout(this.delayTimeout);
        const searchTerm  = event.target.value;
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        this.delayTimeout = setTimeout(() => {
            this.searchTerm = searchTerm;
        }, 300); 
        //This delay reduces the number of Apex calls when the user is typing letters to form a word
    }

    get hasResults(){       
        return (this.bears.data.length > 0);                
    }

    handleBearView(event){
        // Get bear record id from bearview event
        const bearId = event.detail;

        // Navigate to bear record page
        this[NavigationMixin.Navigate]({
			type: 'standard__recordPage',
			attributes: {
				recordId: bearId,
				objectApiName: 'Bear__c',
				actionName: 'view',
			},
		});
    }
}