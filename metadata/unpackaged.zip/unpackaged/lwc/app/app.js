import { LightningElement, track } from 'lwc';

export default class App extends LightningElement {
    name = 'Electra X4';
    description = 'A sweet bike built for comfort.';
    category = 'Mountain';
    material = 'Steel';
    price = '$2,700';
    pictureUrl = 'https://s3-us-west-1.amazonaws.com/sfdc-demo/ebikes/electrax4.jpg';

    //@track - propiedade para monitoramento, renderiza o componenete quando o valor da propriedade é alterado.
    //@api - marca uma propriedade como publica
    //@wire - vincula a dados da organização

    @track
    ready = false;
    
    //connectedCallback() - executado quando o componente é inserido no DOM
    //disconnectedCallback() - executado quando o componente é removido do DOM

    connectedCallback() {
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        setTimeout(() => {
            this.ready = true;
        }, 3000);
    }
}