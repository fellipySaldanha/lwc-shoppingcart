import { LightningElement, track, api } from 'lwc';
import{bikes} from 'c/data';
export default class Detail extends LightningElement {
    @track product;
    //variavel privada para monitorar @api productId
    _productId = undefined;

    set productId(value){
        // eslint-disable-next-line no-console
        console.log('set productId');
        this._productId = value;
        this.product = bikes.find(bike => bike.fields.Id.value === value);
    }

    @api get productId(){
        // eslint-disable-next-line no-console
        console.log('get productId');
        return this._productId;
    }
}