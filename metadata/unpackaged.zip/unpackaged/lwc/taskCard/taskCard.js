import { LightningElement, api } from 'lwc';

export default class TaskCard extends LightningElement {
    //@api atributo privado
    @api Description;
    @api Id;

    editClick(){
        this.sendClickEvent('edit', this.Id);
    }

    deleteClick(){
        this.sendClickEvent('delete', this.Id);
    }

    sendClickEvent(eventName, identification){
        //instanciando um novo evento customizado(nome do evento,paramentros)
        const taskEventClick = new CustomEvent('taskeventclick', {
            //passando os parametros do evento
            detail: {
                Action: eventName,
                Id: identification
            }
        });
        //dispara o evento
        this.dispatchEvent(taskEventClick);
    }
}