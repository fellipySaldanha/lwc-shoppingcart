import { LightningElement, track, wire } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation';
import { registerListener, unregisterAllListeners } from 'c/pubsub';

export default class BearMap extends LightningElement {
    
    @track mapMarkers = [];

    @wire (CurrentPageReference) pageRef; // Required by pubsub

    connectedCallback(){
        registerListener('bearListUpdate', this.handleBearListUpdate, this);
    }

    disconnectedCallback(){
        unregisterAllListeners(this);
    }

    //As soon as we receive a bearListUpdate event, the handleBearListUpdate function gets called with the list of bear records that are currently filtered. 
    //handleBearListUpdate builds a list of map markers that are passed to the mapMarkers property and then displayed on our map component.

    handleBearListUpdate(bears){
        this.mapMarkers = bears.map(bear => {
            const Latitude = bear.Location__Latitude__s;
            const Longitude = bear.Location__Longitude__s;
            return {
                location: { Latitude, Longitude },
				title: bear.Name,
				description: `Coords: ${Latitude}, ${Longitude}`,
				icon: 'utility:animal_and_nature'
            };
        });
    }
}